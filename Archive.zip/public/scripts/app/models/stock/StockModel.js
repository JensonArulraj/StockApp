define([
  'underscore',
  'backbone'
], function(_, Backbone) {
  
  var StockModel = Backbone.Model.extend({});

  return StockModel;

});
