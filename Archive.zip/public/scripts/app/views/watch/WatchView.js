define([
'jquery',
  'underscore',
  'backbone',
  'app/views/watch/WatchView',
  'text!templates/watch/watchTemplate.html'
], function($, _, Backbone, WatchView,  watchTemplate){

  var WatchView = Backbone.View.extend({
    el: $("#stock-details"),
    render: function(){
      
      this.$el.html(watchTemplate);

     
    }
  });

  return WatchView;
});
