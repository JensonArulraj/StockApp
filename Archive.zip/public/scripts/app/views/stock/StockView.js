define([
  'jquery',
  'underscore',
  'backbone',
  'app/models/stock/StockModel',
  'app/collections/stock/StockCollection',
  'app/views/stock/StockView',
  'app/views/stock/StockListView',
  'text!templates/stock/StockTemplate.html',
  'text!templates/watch/WatchTemplate.html'
], function($, _, Backbone, StockModel, StockCollection, StockView, StockListView, StockTemplate,WatchTemplate){

  var StockView = Backbone.View.extend({
	  collections:StockCollection,
    el: $("#page"),
	initialize : function(){
		//this.stockCollection = new StockCollection();
	},
		events:{
			'click #stock-name': 'stockDetails'
	},
    render: function(){
     
	  this.$el.html(StockTemplate);

      /* var project0 = new StockModel({title: 'HealthcareMarket', url: 'https://github.com/thomasdavis/backbonetutorials/tree/gh-pages/examples/cross-domain'}); 
      var project1 = new StockModel({title:'Infinite Scroll', url: 'https://github.com/thomasdavis/backbonetutorials/tree/gh-pages/examples/infinite-scroll'}); 
      var project2 = new StockModel({title:'Modular Backbone', url: 'https://github.com/thomasdavis/backbonetutorials/tree/gh-pages/examples/modular-backbone'}); 
      var project3 = new StockModel({title:'Node MongoDB Mongoose Restify', url: 'https://github.com/thomasdavis/backbonetutorials/tree/gh-pages/examples/nodejs-mongodb-mongoose-restify'});
      var project4 = new StockModel({title:'Todo App', url: 'https://github.com/thomasdavis/backbonetutorials/tree/gh-pages/examples/todo-app'});

      var aProjects = [project0, 
                      project1,
                      project2,
                      project3,
                      project4];*/

    //var stockCollection = this.StockCollection;  

     //var stockCollection = new StockCollection(aProjects);
	 // var stockDataCollection = stockCollection.getData();
	  
	  var stockListView = new StockListView({ collection: StockCollection}); 
      
      stockListView.render(); 

      // add the sidebar 
     // var sidebarView = new SidebarView();
     // sidebarView.render();

    },
	stockDetails:function(){

$("#healthcare-details").html(WatchTemplate);
	}
  });

  return StockView;
});
